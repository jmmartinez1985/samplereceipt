import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { AppService } from "../../../app.service";
import { StorageService } from "../authentication/storage.service";
/**
   _._     _,-'""`-._
  (,-.`._,'(       |\`-/|
      `-.-' \ )-`( , o o)
            `-    \`_`"'-
  @author: Richard Gonzalez
  @last-update: 12-01-22
 */
@Injectable({
  providedIn: "root",
})
export class CoreService {
  url: string;

  constructor(
    private _appSvc: AppService,
    private _http: HttpClient,
    private _storeSvc: StorageService
  ) {
    this.url = `${this._appSvc.getBaseUrl()}core/`;
  }

  searchUsers(payload: any): Observable<any> {
    return this._http.post(`${this.url}user/search`, payload);
  }

  //#endregion
}

//#region Functions
function post(ws: string, payload: any): Observable<any> {
  return this._http.post(`${this.url}${ws}`, payload);
}

//#endregion
