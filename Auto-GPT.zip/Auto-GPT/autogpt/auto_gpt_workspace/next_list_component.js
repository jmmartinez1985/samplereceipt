import React, { useState, useEffect } from 'react';
import axios from 'axios';

const NextListComponent = () => {
  const [list, setList] = useState([]);

  useEffect(() => {
    axios.get('/api/list')
      .then(response => {
        setList(response.data);
      })
      .catch(error => {
        console.error(error);
      });
  }, []);

  return (
    <div>
      {list.map(item => (
        <div key={item.id}>
          {/* item JSX */}
        </div>
      ))}
    </div>
  );
};

export default NextListComponent;