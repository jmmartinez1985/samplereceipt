import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import { CoreService } from './../../../../core/service/core.service';
import { Breadcrumbs } from './../../../../core/models/breadcrumbs';
import { User } from './../../../../core/models/user';

const List = () => {
  const router = useRouter();
  const [usersList, setUsersList] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [showFilters, setShowFilters] = useState<boolean>(false);
  const [request, setRequest] = useState({
    searchText: null,
    userName: null,
    email: null,
    idNumber: null,
    pageNumber: 1,
    pageSize: 10,
  });
  const breadcrumbs: Breadcrumbs[] = [
    {
      name: 'BREADCRUMB.USERS.USERS',
    },
    {
      name: 'BREADCRUMB.USERS.LIST',
      url: '/pages/admin/users',
    },
  ];

  useEffect(() => {
    searchUsers();
  }, []);

  const searchUsers = () => {
    setIsLoading(true);
    const payload = {
      Email: request.email,
      IDNumber: request.idNumber,
      SearchText: request.searchText,
      UserName: request.userName,
      PageNumber: request.pageNumber++,
      PageSize: request.pageSize,
    };
    CoreService.searchUsers(payload)
      .then(({ Data }) => {
        if (Data && Data.length > 0) {
          setUsersList((prev) => [...prev, ...(Data || [])]);
        }
      })
      .finally(() => setIsLoading(false));
  };

  const filtersControl = () => {
    setShowFilters((prev) => !prev);
  };

  const clearFilter = () => {
    setRequest({
      ...request,
      email: null,
      idNumber: null,
      userName: null,
    });
    onSearch();
  };

  const onSearch = () => {
    setRequest({ ...request, pageNumber: 1 });
    setUsersList([]);
    searchUsers();
  };

  const goToInformation = (userId?: string) => {
    if (userId) {
      router.push(`/pages/admin/users/information/${userId}`);
    } else {
      router.push(`/pages/admin/users/information`);
    }
  };

  return (
    <div>
      <h1>List Component</h1>
      {isLoading && <p>Loading...</p>}
      <button onClick={() => filtersControl()}>Filters</button>
      {showFilters && (
        <div>
          <input
            type='text'
            placeholder='Search'
            value={request.searchText}
            onChange={(e) => setRequest({ ...request, searchText: e.target.value })}
          />
          <input
            type='text'
            placeholder='Username'
            value={request.userName}
            onChange={(e) => setRequest({ ...request, userName: e.target.value })}
          />
          <input
            type='text'
            placeholder='Email'
            value={request.email}
            onChange={(e) => setRequest({ ...request, email: e.target.value })}
          />
          <input
            type='text'
            placeholder='ID Number'
            value={request.idNumber}
            onChange={(e) => setRequest({ ...request, idNumber: e.target.value })}
          />
          <button onClick={() => clearFilter()}>Clear Filters</button>
        </div>
      )}
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Email</th>
            <th>ID Number</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {usersList.map((user) => (
            <tr key={user.ID}>
              <td>{user.ID}</td>
              <td>{user.UserName}</td>
              <td>{user.Email}</td>
              <td>{user.IDNumber}</td>
              <td>
                <button onClick={() => goToInformation(user.ID)}>View</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};


export default List;