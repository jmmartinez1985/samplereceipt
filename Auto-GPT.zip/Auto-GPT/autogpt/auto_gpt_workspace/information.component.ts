import { Mdl03Service } from './../../../../core/service/mdl03.service';
import { SecurityInfoModalComponent } from './../../components/security-info-modal/security-info-modal.component';
import { Users, UserSearchResponse } from './../../../../core/models/core';
import { ExternalCodesComponent } from './../../../../shared/components/external-codes/external-codes.component';
import { IntegratedSystem } from './../../../../core/models/mdl10';
import { DefaultToastrService, ToastType } from './../../../../core/service/defaulttoastr.service';
import { StorageService } from './../../../../core/authentication/storage.service';
import { CoreService } from './../../../../core/service/core.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, AbstractControl, FormArray, Validators } from '@angular/forms';
import { Breadcrumbs } from './../../../../core/models/breadcrumbs';
import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { Subject } from 'rxjs';
import { NgbTabset, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { finalize, takeUntil } from 'rxjs/operators';
import {
  clearFormArray,
  emailRegex,
  markFormGroupTouched,
  patchFormArray,
} from '../../../../shared/util/util.component';
import { MinArrayLength } from '../../../../shared/validators/minArrayLength.validator';
/**
   _._     _,-'""`-._
  (,-.`._,'(       |\`-/|
      `-.-' \ )-`( , o o)
            `-    \`_`"'-
  @author: Richard Gonzalez
  @since: 28-04-22
  @last-update: 19-04-22
 */
@Component({
  selector: 'app-information',
  templateUrl: './information.component.html',
  styleUrls: ['./information.component.scss'],
})
export class InformationComponent implements OnInit, OnDestroy {
  @ViewChild('tabset') tabset: NgbTabset;
  @ViewChild(ExternalCodesComponent) externalCodesComponent: ExternalCodesComponent;

  private _unsubscribeAll: Subject<any>;
  breadcrumbs: Breadcrumbs[];
  isLoading: boolean;
  isSaveAndEdit: boolean;
  isSaveAndExit: boolean;
  isLoadingExternalCodes: boolean;
  isLoadingUserStatus: boolean;
  editMode: boolean;
  isDeletingExternalCodes: boolean;
  form: FormGroup;
  externalCodesList: IntegratedSystem[] = [];
  userStatusList: any[] = [];
  userDetail;
  userId: string = null;
  request = {
    searchText: null,
    pageNumber: 1,
    pageSize: 10,
  };

  parentRequiredFields: any[] = [];

  constructor(
    private _activatedRouter: ActivatedRoute,
    private _coreSvc: CoreService,
    private _router: Router,
    private _fb: FormBuilder,
    private _storageSvc: StorageService,
    private _mdl03Svc: Mdl03Service,
    private _modal: NgbModal,
    private _defaultToastrSvc: DefaultToastrService
  ) {
    this._unsubscribeAll = new Subject();
    this.breadcrumbs = [
      {
        name: 'BREADCRUMB.USERS.USERS',
        url: '/pages/admin/users',
      },
      {
        name: 'BREADCRUMB.USERS.LIST',
        url: '/pages/admin/users',
      },
      {
        name: 'BREADCRUMB.USERS.INFO',
      },
    ];
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next();
    this._unsubscribeAll.complete();
  }

  ngOnInit(): void {
    this.userId = this._activatedRouter.snapshot.paramMap.get('userId');
    this.initForm();

    // Obtenemos los campos que son requeridos dinamicamente en el formgroup padre
    Object.keys(this.form.controls).forEach((key) => {
      if (this.form.get(key).errors && this.form.get(key).errors.required) {
        this.parentRequiredFields.push(key);
      }
    });

    if (this.userId) {
      this.editMode = true;
      // Hacemos la verificación para evitar que tome los mismos valores del resolve al momento de darle guardar y seguir editando
      if (!this.userDetail) this.userDetail = this._activatedRouter.snapshot.data.user;

      if (this.userDetail) this.patchForm(this.userDetail);
      this.searchCustomersStatus();
    }
  }

  searchCustomersStatus(): void {
    this.isLoadingUserStatus = true;
    this._mdl03Svc
      .getCustomerStatusList()
      .pipe(finalize(() => (this.isLoadingUserStatus = false)))
      .subscribe(({ Data }) => {
        if (Data && Data.length > 0) {
          this.userStatusList = Data.map(({ CustomerStatusId, CustomerStatusName }) => ({
            CustomerStatusId: CustomerStatusId.toLowerCase(),
            CustomerStatusName: CustomerStatusName,
          }));
        }
      });
  }

  //#region Form
  initForm(): void {
    this.form = this._fb.group({
      Email: [null, [Validators.required, Validators.pattern(emailRegex())]],
      FirstName: [null, Validators.required],
      PhoneNumber: [null],
      LastName: [null, Validators.required],
      Id: [null],
      FullName: [null],
      IDNumber: [null, Validators.required],
      MiddleName: [null],
      Password: [null],
      UserStatusId: [null],
      RolesName: this._fb.array([], MinArrayLength(1)),
      Tenant: this._storageSvc.loadCompanyData[0].SaaSId,
      UserName: [null, Validators.required],
      Customer: this._fb.array([]),
      BranchOffice: this._fb.array([]),
      ExternalCode: this._fb.array([]),
      Status: true,
    });
  }

  get f() {
    return this.form.controls;
  }

  get externalCodes(): FormArray {
    return this.form.get('ExternalCode') as FormArray;
  }
  get branchOffices(): FormArray {
    return this.form.get('BranchOffice') as FormArray;
  }

  get rolesName(): FormArray {
    return this.form.get('RolesName') as FormArray;
  }

  get customers(): FormArray {
    return this.form.get('Customer') as FormArray;
  }

  get fullName(): string {
    return this.form.get('FullName').value;
  }

  get firstName(): string {
    return this.form.get('FirstName').value;
  }

  get lastName(): string {
    return this.form.get('LastName').value;
  }

  concat(name, midName, lastName) {
    return name + ' ' + midName + ' ' + lastName;
  }

  patchForm(userDetail: Users): void {
    this.form.patchValue({
      Id: userDetail.Id,
      Email: userDetail.Email,
      FirstName: userDetail.FirstName,
      PhoneNumber: userDetail.PhoneNumber,
      LastName: userDetail.LastName,
      FullName:
        userDetail.FullName ||
        this.concat(userDetail.FirstName, userDetail.MiddleName ? userDetail.MiddleName : '', userDetail.LastName),
      IDNumber: userDetail.IDNumber,
      MiddleName: userDetail.MiddleName,
      UserName: userDetail.UserName,
      UserStatusId: userDetail.UserStatusId ? userDetail.UserStatusId.toLowerCase() : null,
    });

    if (userDetail.ExternalCode && userDetail.ExternalCode.length > 0) {
      userDetail.ExternalCode.forEach((x) => {
        this.externalCodes.push(
          this._fb.group({
            ...x,
          })
        );
      });
    }

    if (userDetail.Customer && userDetail.Customer.length > 0) {
      userDetail.Customer.forEach((x) => {
        this.customers.push(
          this._fb.group({
            ...x,
          })
        );
      });
    }

    if (userDetail.BranchOffice && userDetail.BranchOffice.length > 0) {
      userDetail.BranchOffice.forEach((x) => {
        this.branchOffices.push(
          this._fb.group({
            ...x,
          })
        );
      });
    }

    if (userDetail.RolesName && userDetail.RolesName.length > 0) {
      userDetail.RolesName.forEach((x) => {
        this.rolesName.push(this._fb.group({ ...x }));
      });
    }
  }

  //#endregion

  //#region functions
  onFillEmail(email: string): void {
    this.form.get('UserName').patchValue(email);
  }

  autoComplete(): void {
    const name = this.form.get('FirstName').value || '';
    const secondName = this.form.get('MiddleName').value || '';
    const lastName = this.form.get('LastName').value || '';

    this.form.get('FullName').patchValue(name + ' ' + secondName + ' ' + lastName);
  }

  onAddExternalCode({ ExternalCode, ExternalSystem, Description, IntegratedSystemId }: IntegratedSystem): void {
    this.externalCodes.push(
      this._fb.group({
        ExternalCode,
        ExternalSystem,
        Description,
        IntegratedSystemId,
      })
    );
  }

  openSecurityInformation(): void {
    const modalRef = this._modal.open(SecurityInfoModalComponent, {
      backdrop: 'static',
      size: 'sm',
    });

    modalRef.componentInstance.userId = this.userId;

    modalRef.result.then(
      (response) => {},
      (error) => {}
    );
  }

  onDeleteExternalCodes = (index: number): void => this.externalCodes.removeAt(index);

  //#endregion

  submit(continueEditing?: boolean): void {
    continueEditing ? (this.isSaveAndEdit = true) : (this.isSaveAndExit = true);

    if (!this.form.valid) {
      continueEditing ? (this.isSaveAndEdit = false) : (this.isSaveAndExit = false);
      markFormGroupTouched(this.form);
      this._defaultToastrSvc.WarningFieldRequiredToast();
      return;
    }

    const payload = this.form.getRawValue();
    const roles = [];
    payload.RolesName.forEach((x) => {
      roles.push(x.Name);
    });
    payload.RolesName = roles;

    (this.editMode ? this._coreSvc.updateUser(payload) : this._coreSvc.createUser(payload))
      .pipe(
        takeUntil(this._unsubscribeAll),
        finalize(() => (continueEditing ? (this.isSaveAndEdit = false) : (this.isSaveAndExit = false)))
      )
      .subscribe(({ Status, Data }) => {
        if (Status.Code === 200) {
          this.editMode ? this._defaultToastrSvc.SuccessUpdateToast() : this._defaultToastrSvc.SuccessCreateToast();
          if (continueEditing) {
            if (this.editMode) {
              // Limpiamos cada uno de los formArrays para evitar que se añadan duplicados
              clearFormArray(this.externalCodes);
              clearFormArray(this.branchOffices);
              clearFormArray(this.customers);
              clearFormArray(this.rolesName);
              // Hacemos patch de la data que cambiamos
              this.patchForm(Data);
            } else {
              this._router.navigate([`pages/admin/users/information/${Data.Id}`]);
            }
          } else {
            this.redirectToList();
          }
        } else {
          this._defaultToastrSvc.CustomToast(ToastType.Error, Status.Message, 'Error', Status.Message, 'Error');
        }
      });
  }

  get generalFieldsInvalid(): boolean {
    let invalid: boolean;
    for (const x of this.parentRequiredFields) {
      if (!this.form.get(x).valid && this.form.get(x).touched) {
        invalid = true;
        break;
      } else {
        invalid = false;
      }
    }
    return invalid;
  }

  redirectToList(): void {
    this._router.navigate([`pages/admin/users/list`]);
  }
}
