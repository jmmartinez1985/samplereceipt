import { HttpClient } from 'next/http';
import { AppService } from '../../../app.service';
import { StorageService } from '../authentication/storage.service';
import { Observable } from 'rxjs';

export class CoreService {
  url: string;

  constructor(
    private _appSvc: AppService,
    private _http: HttpClient,
    private _storeSvc: StorageService
  ) {
    this.url = `${this._appSvc.getBaseUrl()}core/`;
  }

  searchUsers(payload: any): Observable<any> {
    return this._http.post(`${this.url}user/search`, payload);
  }

  //#endregion
}

//#region Functions
function post(ws: string, payload: any): Observable<any> {
  return this._http.post(`${this.url}${ws}`, payload);
}

//#endregion
