with open('TableList.tsx', 'r') as f:
    contents = f.read()
    print(contents)