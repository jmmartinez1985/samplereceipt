with open('coreSvc.js', 'r') as f:
    data = f.read()
data = data.replace('this.url', 'https://qa-apim.aludra.cloud/')

with open('finished.ts', 'r') as f:
    filedata = f.read()

newdata = filedata.replace('this.url', 'https://qa-apim.aludra.cloud/')

with open('finished.ts', 'w') as f:
    f.write(newdata)