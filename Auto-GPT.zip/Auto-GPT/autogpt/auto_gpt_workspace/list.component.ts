import { takeUntil, finalize } from 'rxjs/operators';
import { CoreService } from './../../../../core/service/core.service';
import { Router } from '@angular/router';
import { Breadcrumbs } from './../../../../core/models/breadcrumbs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subject } from 'rxjs';
/**
   _._     _,-'""`-._
  (,-.`._,'(       |\`-/|
      `-.-' \ )-`( , o o)
            `-    \`_`"'-
  @author: Richard Gonzalez
  @since: 24-12-2021
  @last-update: 29-12-2021
 */
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss'],
})
export class ListComponent implements OnInit, OnDestroy {
  private _unsubscribeAll: Subject<any>;
  breadcrumbs: Breadcrumbs[];
  usersList: any[] = [];
  isLoading: boolean;

  request = {
    searchText: null,
    userName: null,
    email: null,
    idNumber: null,
    pageNumber: 1,
    pageSize: 10,
  };

  showFilters: boolean;

  constructor(private _router: Router, private _coreSvc: CoreService) {
    this._unsubscribeAll = new Subject();

    this.breadcrumbs = [
      {
        name: 'BREADCRUMB.USERS.USERS',
      },
      {
        name: 'BREADCRUMB.USERS.LIST',
        url: '/pages/admin/users',
      },
    ];
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next();
    this._unsubscribeAll.complete();
  }

  ngOnInit(): void {
    this.searchUsers();
  }

  searchUsers(): void {
    this.isLoading = true;
    const payload = {
      Email: this.request.email,
      IDNumber: this.request.idNumber,
      SearchText: this.request.searchText,
      UserName: this.request.userName,
      PageNumber: this.request.pageNumber++,
      PageSize: this.request.pageSize,
    };
    this._coreSvc
      .searchUsers(payload)
      .pipe(
        takeUntil(this._unsubscribeAll),
        finalize(() => (this.isLoading = false))
      )
      .subscribe(({ Data }) => {
        if (Data && Data.length > 0) {
          this.usersList.push(...(Data || []));
        }
      });
  }

  filtersControl(): void {
    this.showFilters = !this.showFilters;
  }

  clearFilter(): void {
    this.request.email = null;
    this.request.idNumber = null;
    this.request.userName = null;
    this.onSearch();
  }

  onSearch(): void {
    this.request.pageNumber = 1;
    this.usersList = [];
    this.searchUsers();
  }

  goToInformation(userId?: string): void {
    if (userId) {
      this._router.navigate([`pages/admin/users/information/${userId}`]);
    } else {
      this._router.navigate([`pages/admin/users/information`]);
    }
  }
}
