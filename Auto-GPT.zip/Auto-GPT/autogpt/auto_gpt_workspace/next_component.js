import React, { useEffect } from 'react';

const ExampleComponent = () => {
  useEffect(() => {
    // ngOnInit equivalent
    return () => {
      // ngOnDestroy equivalent
    }
  }, []);

  return (
    <div>
      // Component template goes here
    </div>
  );
};

export default ExampleComponent;